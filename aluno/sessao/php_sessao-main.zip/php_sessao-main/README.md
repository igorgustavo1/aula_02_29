# php_sessao
Exemplo de estrutura condicional com sessão em PHP
